create definer = java@`%` view type_v as
select `t`.`id`                                                                                                 AS `id`,
       `t`.`name`                                                                                               AS `name`,
       `t`.`info`                                                                                               AS `info`,
       `t`.`date_cr`                                                                                            AS `date_cr`,
       `u`.`username`                                                                                           AS `cr_by`,
       (case `t`.`unit`
          when '1' then 'Dona'
          when '2' then 'Kg'
          when '3' then 'Rulon'
          when '4'
            then 'Litr' end)                                                                                    AS `unit`
from (`sbd_factory`.`type` `t`
       join `sbd_factory`.`user` `u`)
where (`t`.`cr_by` = `u`.`id`);

