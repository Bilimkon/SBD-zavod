create definer = java@`%` view product_v as
select `p`.`id`                                                                                                 AS `id`,
       (case `p`.`unit`
          when '1' then 'Dona'
          when '2' then 'Kg'
          when '3' then 'Rulon'
          when '4'
            then 'Litr' end)                                                                                    AS `unit`,
       `p`.`barcode`                                                                                            AS `barcode`,
       `p`.`name`                                                                                               AS `name`,
       `p`.`type`                                                                                               AS `type`,
       `p`.`cost`                                                                                               AS `cost`,
       `p`.`quantity`                                                                                           AS `quantity`,
       (`p`.`quantity` * `p`.`cost`)                                                                            AS `total_cost`,
       `p`.`weight`                                                                                             AS `weight`,
       `s`.`companyName`                                                                                        AS `suplier`,
       `p`.`date_cr`                                                                                            AS `date_cr`,
       `u`.`username`                                                                                           AS `user`,
       `p`.`description`                                                                                        AS `description`,
       `p`.`width`                                                                                              AS `width`,
       `p`.`height`                                                                                             AS `height`,
       `p`.`color`                                                                                              AS `color`
from ((`sbd_factory`.`product` `p` join `sbd_factory`.`suplier` `s`)
       join `sbd_factory`.`user` `u`)
where ((`p`.`cr_by` = `u`.`id`) and (`p`.`suplier_id` = `s`.`id`));

