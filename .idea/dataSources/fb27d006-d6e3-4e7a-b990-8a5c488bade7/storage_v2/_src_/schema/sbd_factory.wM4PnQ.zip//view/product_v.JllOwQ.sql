create view product_v as
select `p`.`id`                                                      AS `id`,
       (case `p`.`unit` when '1' then 'Dona' when '2' then 'Kg' end) AS `unit`,
       `p`.`barcode`                                                 AS `barcode`,
       `p`.`name`                                                    AS `name`,
       `p`.`type`                                                    AS `type`,
       `p`.`cost`                                                    AS `cost`,
       `p`.`quantity`                                                AS `quantity`,
       (`p`.`quantity` * `p`.`cost`)                                 AS `total_cost`,
       `p`.`weight`                                                  AS `weight`,
       `s`.`firstName`                                               AS `suplier`,
       `p`.`date_cr`                                                 AS `date_cr`
from (`sbd_factory`.`product` `p`
       join `sbd_factory`.`suplier` `s`)
where (`p`.`suplier_id` = `s`.`id`);

