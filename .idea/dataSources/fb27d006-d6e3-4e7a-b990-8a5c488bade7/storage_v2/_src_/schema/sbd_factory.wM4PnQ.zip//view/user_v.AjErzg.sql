create definer = java@`%` view user_v as
select `u`.`id`                      AS `id`,
       `u`.`username`                AS `username`,
       `u`.`firstname`               AS `firstname`,
       `u`.`lastname`                AS `lastname`,
       `u`.`password`                AS `password`,
       `u`.`phone`                   AS `phone`,
       (case `u`.`userType`
          when '1' then 'Ombor'
          when '2' then '1-ish/ch'
          when '3' then '2-ish/ch'
          when '4' then 'Savdo'
          when '5' then 'Admin' end) AS `userType`
from `sbd_factory`.`user` `u`
order by `u`.`id`;

